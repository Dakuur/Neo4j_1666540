# Projecte Neo4j Grup 13

Bases de dades no relacionals. Curs 2023-2024

Professora: Alicia Fornes Bisquerra

Participants i NIUs:
-  Adrià Muro Gómez (1665191) 
-  David Morillo Massagué (1666540) 
-  Albert Guillaumet Mata (1672344) 
-  Lucía Garrido Rosas (1671463)

